module termpj {
	requires java.desktop;
}